import numpy as np
import matplotlib.pyplot as plt

from AB_model import Agent, Group, Pop, Pop_Graph
from AB_simulation import plot_marks


def extension(parameters, T, folder_name=None, n_groups=20):
    Agent.H = 1.0
    Agent.L = parameters["L"]
    Agent.a = parameters["a"]
    Group.n = parameters["n"]

    Group.beta = parameters["beta"]
    Group.gamma = 0

    Pop.h0 = parameters["h0"]
    T = T

    n_agents = Group.n * n_groups
    alpha = 1 / (abs(1 / Group.n - Agent.a) + (Group.n - 1) / Group.n) / (Agent.H - Agent.L)
    Pop_Graph.alpha = alpha

    graph = Pop_Graph(n_agents, parameters)
    if folder_name:
        graph.statistics()

    h = np.zeros(T + 1)
    marks = np.zeros((T, n_groups))
    copyh = np.zeros(T)
    copyl = np.zeros(T)

    h[0] = graph.get_h()
    groups = [Group(graph.graph) for _ in range(n_groups)]

    for t in range(T):
        if folder_name:
            graph.draw_image(folder_name, t)

        for j, group in enumerate(groups):
            # Form groups
            group.add_agent(graph.pick_highest_node())
            for _ in range(Group.n - 1):
                group.add_highest_link()

            marks[t, j] = group.give_marks()
            group.rewire()

            group.agents = []
            group.links = {}

        graph.highest = 0
        graph.update_sum_links()
        copyh[t], copyl[t] = graph.copy_strategies()

        h[t + 1] = graph.get_h()

    if folder_name:
        graph.statistics()
        with open(folder_name + "/params.txt", mode='w') as a_file:
            a_file.write(str(parameters))

    return graph, h, marks, copyh, copyl


def run_simple():
    parameters = {
        "a": 0.2,
        "n": 6,
        "beta": 0.1,
        "h0": 0.5,
        "L": 0,
        "p": 0.1,
        "k": 6,
    }
    n_groups = 20
    T = 150
    folder_name = "cachis"

    n_iter = 50

    h = np.zeros((n_iter, T + 1))
    marks = np.zeros((n_iter, T, n_groups))
    copyh = np.zeros((n_iter, T))
    copyl = np.zeros((n_iter, T))

    # Running iterations
    for i in range(n_iter):
        print(i)
        graph, h[i, :], marks[i, :, :], copyh[i, :], copyl[i, :] = extension(parameters, T=T, folder_name=folder_name)
        if i == 0:
            folder_name = None

    # Plotting
    hstd = h.std(axis=0)
    hstd[::2] = 0

    fig, ax = plt.subplots(2, 2, figsize=(14, 10))
    ax0 = ax[0][0]
    ax1 = ax[0][1]
    ax2 = ax[1][0]
    ax3 = ax[1][1]

    ax0.errorbar(range(T + 1), h.mean(axis=0), yerr=hstd)
    ax0.set(ylim=0, xlabel="t", ylabel="h(t)")

    ax1.plot(h.T, alpha=0.3, color="orange")
    ax1.set(ylim=0, xlabel="t", ylabel="h(t)")

    plot_marks(marks, T, n_iter, ax2)

    ax3.plot(copyh.mean(axis=0), label='H copying')
    ax3.plot(copyl.mean(axis=0), label='L copying')
    ax3.set(xlabel="t", ylabel="n")
    ax3.legend()

    fig.show()

    return h, marks, copyh, copyl


if __name__ == "__main__":
    parameters = {
        "a": 0.2,
        "n": 6,
        "beta": 0.1,
        "h0": 0.5,
        "L": 0,
        "p": 0.1,
        "k": 6,
    }
    ### Graph testing
    # Pop.h0 = parameters["h0"]
    # pop = Pop_Graph(120, parameters)

    ### Single run
    graph, h, m, ch, cl = extension(parameters, T=50, folder_name="gaviota", n_groups=20)

    ### Plotting
    #h, marks, copyh, copyl = run_simple()
